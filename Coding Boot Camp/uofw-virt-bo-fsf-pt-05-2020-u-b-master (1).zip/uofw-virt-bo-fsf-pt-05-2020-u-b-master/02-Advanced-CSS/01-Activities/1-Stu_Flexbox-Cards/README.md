# Flexbox Card Layout

In this activity you will take the provided code and make it resemble the mockup provided.

## Instructions

* Using the provided mockup, use flexbox to replicate the layout.

* **Hint** Each card is also its own flexbox!